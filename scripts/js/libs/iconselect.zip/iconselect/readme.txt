   Code: IconSelect JS

   Year: 8 Dec 2013
   Autor: Buğra ÖZDEN
   Mail: bugra.ozden@gmail.com
   Site: bugraozden.com


   You are free:

   to Share — to copy, distribute and transmit the work
   to Remix — to adapt the work
   to make commercial use of the work

   <http://creativecommons.org/licenses/by/3.0/>


   Have Fun.